# 00 Start Here

Overall counts. Start with Summary.csv; counts across other files overlap.

| CSV | Data rows |
|---|---:|
| [Summary.csv](Summary.csv) | 4 |
