# Mulai di sini

Ringkasan seluruh hasil. Angka pada file lain dapat saling tumpang tindih; jangan dijumlahkan antarfile.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Summary.csv](Summary.csv) | 4 |
