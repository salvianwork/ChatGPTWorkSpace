# Mulai di sini

Mulai dari `BACA_INI_DULU.md`.

- `KAMUS_ISTILAH.md`: penjelasan istilah dalam bahasa sederhana beserta contoh.
- `Kamus_Istilah.csv`: versi kamus yang dapat dicari atau difilter.
- `Ringkasan_Mencapai_Jumlah_Master.csv`: data yang sudah benar, perlu diperbaiki, calon data baru, dan data yang masih perlu diperiksa sebelum membuat data baru.
- `Ringkasan_Record_Salesforce_Lain.csv`: data duplikat dan data Salesforce lain yang masih perlu diperiksa.
- `Summary.csv`: ringkasan teknis yang tetap disediakan sebagai referensi.

Jangan langsung menjumlahkan angka dari file yang berbeda karena file tersebut dapat membahas kelompok data yang berbeda.
