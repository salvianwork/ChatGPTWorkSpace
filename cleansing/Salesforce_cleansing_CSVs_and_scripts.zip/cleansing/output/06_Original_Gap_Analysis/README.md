# 06 Original Gap Analysis

Records and counts from the original workbook gap analysis, plus reconciliation to the full hierarchy analysis. A subset/view of the other worklists.

| CSV | Data rows |
|---|---:|
| [Gap_analysis_reconciliation.csv](Gap_analysis_reconciliation.csv) | 4 |
| [Gap_invalid_summary.csv](Gap_invalid_summary.csv) | 4 |
| [Kecamatan_gap_invalid_mapping.csv](Kecamatan_gap_invalid_mapping.csv) | 1,125 |
| [Kelurahan_gap_invalid_mapping.csv](Kelurahan_gap_invalid_mapping.csv) | 24,340 |
| [KotaKabupaten_gap_invalid_mapping.csv](KotaKabupaten_gap_invalid_mapping.csv) | 378 |
| [Provinsi_gap_invalid_mapping.csv](Provinsi_gap_invalid_mapping.csv) | 0 |
