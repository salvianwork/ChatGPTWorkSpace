# 07 Audit

Input checksums, validation results, and machine-readable summaries. Reference only; never upload these to Salesforce.

| CSV | Data rows |
|---|---:|
| [Input_manifest.csv](Input_manifest.csv) | 5 |
