# Audit

Checksum berkas masukan dan hasil validasi teknis. Bukan data untuk diunggah ke Salesforce.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Input_manifest.csv](Input_manifest.csv) | 5 |
