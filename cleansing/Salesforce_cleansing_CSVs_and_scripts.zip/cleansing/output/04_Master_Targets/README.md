# Target dan masalah master

Inventaris master, target belum terverifikasi, masalah ID, dan hierarki ganda. Target belum pasti bukan berarti harus langsung membuat record baru.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Master_data_issues.csv](Master_data_issues.csv) | 4,460 |
| [Master_duplicate_paths.csv](Master_duplicate_paths.csv) | 4 |
| [Master_target_inventory.csv](Master_target_inventory.csv) | 91,588 |
| [Missing_or_unresolved_master_targets.csv](Missing_or_unresolved_master_targets.csv) | 30,574 |
