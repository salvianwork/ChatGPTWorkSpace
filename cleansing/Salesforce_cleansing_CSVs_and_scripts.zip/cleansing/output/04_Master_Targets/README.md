# 04 Master Targets

Master inventory, unresolved Salesforce target IDs, and master-data issues. Unresolved targets are not all confirmed inserts; reconcile existing records and parents first.

| CSV | Data rows |
|---|---:|
| [Master_data_issues.csv](Master_data_issues.csv) | 4,460 |
| [Master_duplicate_paths.csv](Master_duplicate_paths.csv) | 4 |
| [Master_target_inventory.csv](Master_target_inventory.csv) | 91,588 |
| [Missing_or_unresolved_master_targets.csv](Missing_or_unresolved_master_targets.csv) | 30,574 |
