# Usulan pembaruan

Usulan perubahan nama atau lookup induk. Tinjau sebelum menyiapkan file upload yang hanya memuat Id dan kolom API yang disetujui. Kolom usulan kosong berarti tidak diubah, bukan dihapus.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Kecamatan_canonical_update_proposals.csv](Kecamatan_canonical_update_proposals.csv) | 608 |
| [Kelurahan_canonical_update_proposals.csv](Kelurahan_canonical_update_proposals.csv) | 7,529 |
| [KotaKabupaten_canonical_update_proposals.csv](KotaKabupaten_canonical_update_proposals.csv) | 458 |
| [Provinsi_canonical_update_proposals.csv](Provinsi_canonical_update_proposals.csv) | 0 |
