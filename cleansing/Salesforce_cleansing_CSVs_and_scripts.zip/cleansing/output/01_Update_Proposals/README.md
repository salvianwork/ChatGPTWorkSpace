# 01 Update Proposals

Proposed name/parent corrections. Review first; retain Id and only approved changed Salesforce fields in a separate upload file. Blank proposed fields mean no change. Do not upload audit columns.

| CSV | Data rows |
|---|---:|
| [Kecamatan_canonical_update_proposals.csv](Kecamatan_canonical_update_proposals.csv) | 608 |
| [Kelurahan_canonical_update_proposals.csv](Kelurahan_canonical_update_proposals.csv) | 7,529 |
| [KotaKabupaten_canonical_update_proposals.csv](KotaKabupaten_canonical_update_proposals.csv) | 458 |
| [Provinsi_canonical_update_proposals.csv](Provinsi_canonical_update_proposals.csv) | 0 |
