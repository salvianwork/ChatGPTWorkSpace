# 05 All Records

Complete reference exports with one mapping row per source record, including records that need no change. Reference only.

| CSV | Data rows |
|---|---:|
| [Kecamatan_all_records.csv](Kecamatan_all_records.csv) | 7,828 |
| [Kelurahan_all_records.csv](Kelurahan_all_records.csv) | 82,550 |
| [KotaKabupaten_all_records.csv](KotaKabupaten_all_records.csv) | 890 |
| [Provinsi_all_records.csv](Provinsi_all_records.csv) | 38 |
