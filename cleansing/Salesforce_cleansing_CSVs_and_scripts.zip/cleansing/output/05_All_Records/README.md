# Seluruh record

Satu baris per record sumber, termasuk yang sudah valid. Gunakan sebagai referensi dan jejak pemeriksaan.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Kecamatan_all_records.csv](Kecamatan_all_records.csv) | 7,828 |
| [Kelurahan_all_records.csv](Kelurahan_all_records.csv) | 82,550 |
| [KotaKabupaten_all_records.csv](KotaKabupaten_all_records.csv) | 890 |
| [Provinsi_all_records.csv](Provinsi_all_records.csv) | 38 |
