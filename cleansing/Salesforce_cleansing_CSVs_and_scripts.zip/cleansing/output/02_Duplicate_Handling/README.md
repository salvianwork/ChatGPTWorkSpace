# 02 Duplicate Handling

Source-to-target duplicate mappings. Confirm and repoint all references before retiring any source record. This is not an upload or deletion list.

| CSV | Data rows |
|---|---:|
| [Duplicate_repoint_proposals.csv](Duplicate_repoint_proposals.csv) | 3,105 |
