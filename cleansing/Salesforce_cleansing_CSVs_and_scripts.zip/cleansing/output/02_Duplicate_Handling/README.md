# Penanganan duplikat

Pemetaan Id sumber ke Id target. Verifikasi seluruh referensi sebelum memindahkannya. File ini bukan daftar upload atau penghapusan.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Duplicate_repoint_proposals.csv](Duplicate_repoint_proposals.csv) | 3,105 |
