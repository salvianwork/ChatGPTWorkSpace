# Tinjauan manual

Daftar kerja cleansing, kandidat, serta temuan lintas tingkat. Temuan nama pada tingkat lain tidak membuktikan bahwa lokasinya sama. Semua ID kandidat lintas tingkat dikosongkan.

| Berkas CSV | Jumlah baris data |
|---|---:|
| [Cross_level_name_review.csv](Cross_level_name_review.csv) | 460 |
| [Kecamatan_cleansing_mapping.csv](Kecamatan_cleansing_mapping.csv) | 1,747 |
| [Kelurahan_cleansing_mapping.csv](Kelurahan_cleansing_mapping.csv) | 36,304 |
| [KotaKabupaten_cleansing_mapping.csv](KotaKabupaten_cleansing_mapping.csv) | 836 |
| [Provinsi_cleansing_mapping.csv](Provinsi_cleansing_mapping.csv) | 0 |
| [Review_candidates.csv](Review_candidates.csv) | 67,606 |
