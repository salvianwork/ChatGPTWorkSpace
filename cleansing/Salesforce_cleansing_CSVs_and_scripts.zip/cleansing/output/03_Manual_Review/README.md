# 03 Manual Review

Cleansing worklists, possible matches, and administrative-level questions. Resolve review statuses before applying a suggestion. Candidate rows can repeat a source record.

| CSV | Data rows |
|---|---:|
| [Cross_level_name_review.csv](Cross_level_name_review.csv) | 460 |
| [Kecamatan_cleansing_mapping.csv](Kecamatan_cleansing_mapping.csv) | 1,747 |
| [Kelurahan_cleansing_mapping.csv](Kelurahan_cleansing_mapping.csv) | 36,304 |
| [KotaKabupaten_cleansing_mapping.csv](KotaKabupaten_cleansing_mapping.csv) | 836 |
| [Provinsi_cleansing_mapping.csv](Provinsi_cleansing_mapping.csv) | 0 |
| [Review_candidates.csv](Review_candidates.csv) | 61,135 |
