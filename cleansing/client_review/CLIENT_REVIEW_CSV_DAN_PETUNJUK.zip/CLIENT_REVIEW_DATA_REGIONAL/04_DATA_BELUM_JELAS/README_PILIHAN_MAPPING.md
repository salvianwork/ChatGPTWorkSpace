# Pilihan mapping lengkap

`Pilihan_Mapping.csv` berisi seluruh pilihan dan petunjuk untuk data yang belum jelas.

Client tidak perlu membaca seluruh file ini terlebih dahulu. Mulai dari lembar `DATA BELUM JELAS` dalam workbook. Lembar tersebut menampilkan maksimal tiga pilihan utama untuk setiap record.

Gunakan file ini jika:

- Client membutuhkan pilihan selain tiga pilihan utama.
- Client ingin melihat alasan lengkap setiap kandidat.
- Nama ditemukan pada tingkat wilayah lain.
- Client perlu menelusuri semua lokasi yang mempunyai nama serupa.

Baris dengan `Kegunaan = Petunjuk nama pada tingkat wilayah lain; bukan mapping otomatis` tidak boleh langsung dipilih sebagai ID tujuan.
