# Paket review client — data regional Salesforce

Paket ini digunakan untuk mengonfirmasi data Provinsi, Kota/Kabupaten, Kecamatan, dan Kelurahan sebelum perubahan dilakukan di Salesforce.

Belum ada data Salesforce yang diubah atau dihapus.

## File utama

Buka `Mandatory for Client/01_REVIEW_CLIENT_SEDERHANA.xlsx` terlebih dahulu. Client cukup memberikan 14 keputusan utama dan hanya mencatat record yang menjadi pengecualian. Gunakan `Mandatory for Client/02_REVIEW_CLIENT_DATA_REGIONAL.xlsx` hanya jika membutuhkan rincian record.

Gunakan `MAPPING_ID_INVALID_KE_VALID.xlsx` untuk menentukan satu ID Salesforce yang tidak akan dipakai lagi harus diarahkan ke ID Salesforce mana. File ini digunakan sebagai dasar pemindahan hubungan data wilayah dan data transaksi setelah keputusan client selesai.

Kolom yang perlu diisi client diberi nama seperti `Keputusan_Client`, `Pilihan_Client`, `Id_Target_Final_Client`, dan `Catatan_Client`. Kolom keputusan diberi warna kuning dan mempunyai pilihan jawaban.

## Urutan review

1. Baca folder `00_BACA_DULU`.
2. Konfirmasi perubahan pada folder `01_DATA_PERLU_DIUBAH`.
3. Periksa calon data baru pada folder `02_CALON_DATA_BARU`.
4. Konfirmasi data duplikat pada folder `03_DATA_DUPLIKAT`.
5. Tentukan pemetaan data yang belum jelas pada folder `04_DATA_BELUM_JELAS`.
6. Gunakan folder `05_DATA_SUDAH_SESUAI_MASTER` untuk melihat record yang sudah sesuai. Folder ini hanya referensi dan tidak perlu diisi.
7. Gunakan folder `06_REFERENSI` jika membutuhkan daftar master yang belum terpenuhi atau penjelasan hubungan wilayah.

Kerjakan secara berurutan: Provinsi → Kota/Kabupaten → Kecamatan → Kelurahan.

## Catatan penting

- Data pada folder `05_DATA_SUDAH_SESUAI_MASTER` tidak memerlukan perubahan.
- Kandidat bukan keputusan final.
- Nama yang ditemukan pada tingkat wilayah lain hanya menjadi petunjuk dan tidak mempunyai ID tujuan otomatis.
- Calon data baru harus diperiksa kembali agar tidak membuat data duplikat.
- Untuk data duplikat, semua hubungan dari data lain harus dipindahkan sebelum record dinonaktifkan atau dihapus.
- File dalam paket ini bukan file upload siap pakai.
