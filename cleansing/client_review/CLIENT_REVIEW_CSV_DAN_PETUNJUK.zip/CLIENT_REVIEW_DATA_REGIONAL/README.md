# Paket review client — data regional Salesforce

Paket ini digunakan untuk mengonfirmasi data Provinsi, Kota/Kabupaten, Kecamatan, dan Kelurahan sebelum perubahan dilakukan di Salesforce.

Belum ada data Salesforce yang diubah atau dihapus.

## File utama

Buka `REVIEW_CLIENT_DATA_REGIONAL.xlsx` terlebih dahulu. Workbook tersebut berisi petunjuk, ringkasan, kamus istilah, data yang perlu diubah, calon data baru, data duplikat, dan data yang belum jelas.

Kolom yang perlu diisi client diberi nama seperti:

- `Keputusan_Client`
- `Pilihan_Client`
- `Id_Target_Final_Client`
- `Nama_Final_Client`
- `Id_Induk_Final_Client`
- `Catatan_Client`
- `PIC_Client`
- `Tanggal_Konfirmasi`

Pada workbook, kolom `Keputusan_Client` diberi warna kuning dan mempunyai pilihan jawaban.

## Urutan review

1. Baca folder `00_BACA_DULU`.
2. Konfirmasi perubahan pada folder `01_DATA_PERLU_DIUBAH`.
3. Periksa calon data baru pada folder `02_CALON_DATA_BARU`.
4. Konfirmasi data duplikat pada folder `03_DATA_DUPLIKAT`.
5. Tentukan mapping data yang belum jelas pada folder `04_DATA_BELUM_JELAS`.
6. Gunakan folder `05_REFERENSI` jika membutuhkan daftar master yang belum terpenuhi atau penjelasan hubungan wilayah.

Kerjakan secara berurutan: Provinsi → Kota/Kabupaten → Kecamatan → Kelurahan.

## Catatan penting

- Kandidat bukan keputusan final.
- Nama yang ditemukan pada tingkat wilayah lain hanya menjadi petunjuk dan tidak mempunyai ID tujuan otomatis.
- Calon data baru harus diperiksa kembali agar tidak membuat data duplikat.
- Untuk data duplikat, semua hubungan dari data lain harus dipindahkan sebelum record dinonaktifkan atau dihapus.
- File dalam paket ini bukan file upload siap pakai.
