# Data yang sudah sesuai master

Folder ini berisi record Salesforce yang sudah cocok dengan master dan dipertahankan sebagai data utama.

- `Provinsi_Sudah_Sesuai.csv`: 38 record.
- `KotaKabupaten_Sudah_Sesuai.csv`: 54 record.
- `Kecamatan_Sudah_Sesuai.csv`: 6.081 record.
- `Kelurahan_Sudah_Sesuai.csv`: 46.246 record.

File ini hanya digunakan sebagai dasar pemeriksaan dan tidak memerlukan keputusan client. Kolom `Hierarki_Sesuai_Master` menunjukkan susunan wilayah yang menjadi dasar kecocokan. Kolom `Catatan_Pemeriksaan` perlu dibaca jika terisi.
